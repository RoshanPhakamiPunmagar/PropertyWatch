package au.cqu.edu.propertywatch.api


class WatchrResponse {
    // Properties field containing the list of properties retrieved from the API
    lateinit var properties: PropertyResponse
}
